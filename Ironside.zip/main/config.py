#SQLALCHEMY_DATABASE_URI = 'mysql://root:@127.0.0.1:4080/NatterDB'

#SQLALCHEMY_TRACK_MODIFICATIONS = True

userpass = 'mysql://root:@'
basedir = '127.0.0.1'
dbname = '/Natter'

SQLALCHEMY_DATABASE_URI = userpass + basedir + dbname

SQLALCHEMY_TRACK_MODIFICATIONS = True

SECRET_KEY = 'Salahudeen_Hazizat'