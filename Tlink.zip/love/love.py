from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)

userpass = 'mysql://root:@'
basedir = '127.0.0.1'
dbname = '/love'



app.config['SQLALCHEMY_DATABASE_URI']=userpass + basedir + dbname
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SECRET_KEY'] = 'Love'
db = SQLAlchemy(app)


login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
db.init_app(app)
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))  

class Talk(db.Model):
    __name__ = "Talk"
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.String(5000))
    user = db.Column(db.String(100))
    date_posted= db.Column(db.DateTime)

class User(db.Model, UserMixin):
    __name__ = "User"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100))
    password = db.Column(db.String(100))  

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/index')
def hello_world():
	#return "hi"

	return render_template('index.html')

@app.route('/registration', methods=['GET', 'POST'])
def registration():
	if request.method == 'POST':
		try:
			username = request.form['username']
			password = request.form['password']
			hashed_password = generate_password_hash(password, method='sha256')
			new_user = User(username=username,password=hashed_password)
			db.session.add(new_user)
			db.session.commit()
		except IntegrityError:
			flash('some one as sign up with the username try another one')
			return render_template('index.html')


		flash("you account is created")
		return render_template('index.html')

	return render_template('reg.html')


@app.route('/login', methods = ['GET','POST'])
def login():
	if request.method == "POST":
		username = request.form['username']
		password = request.form['password']
		#remember = request.form['remember']
		user = User.query.filter_by(username=username).first()
		if user:
			if check_password_hash(user.password,password):
				login_user(user)
				return redirect(url_for('chat'))

			flash("invalid username and password")
			return render_template('index.html')
	#flash("invalid username and password")		
	return render_template('index.html')
	


@app.route('/chat')
@login_required
def chat():
	post = Talk.query.order_by(Talk.date_posted.asc()).all()
	return render_template('chat.html',post=post)
@app.route('/chatprocessor',methods= ['POST'])
def chatprocessor():
	chat = request.form['Chat']
	msg = Talk(message=chat,date_posted=datetime.now(),user=current_user.username)
	db.session.add(msg)
	db.session.commit()
	return redirect(url_for('chat'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("your account has been logged out click get started to login again")
    return redirect(url_for('home'))	


if __name__ == '__main__':
    app.run( host = '0.0.0.0',port =5154 , debug=True)